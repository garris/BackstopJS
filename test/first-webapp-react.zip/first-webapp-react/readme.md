This project demo was found here...

http://tutorialzine.com/2015/04/first-webapp-react/

Install:
`npm install`

Build:
`npm run build`


To test, change directory...
`cd node_modules/backstopjs/`

...then
`npm run test`
