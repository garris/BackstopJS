module.exports = function(casper, scenario, vp) {
  // casper.on('resource.received', function(resource) {
  //   casper.echo(resource.url);
  // });
};
